import Form from "../../components/form/Form";
import "./loginPage.css";

const Login = () => {
  return (
    <div className="login-page">
      <div className="login-container">
        <h1 className="login-title">Welcome Back</h1>

        <Form
          loginData={[
            { name: "Username / Email", type: "text" },
            { name: "Password", type: "password" },
          ]}
          buttonText="Login"
          bgcolor="blue"
          color="white"
        />
      </div>
    </div>
  );
};

export default Login;