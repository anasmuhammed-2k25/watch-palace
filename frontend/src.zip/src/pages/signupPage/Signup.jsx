import Form from "../../components/form/Form";
import "./signupPage.css";

const Signup = () => {
  return (
    <div className="signup-page">
      <div className="signup-content">
        <h1 className="signup-title">Create Account</h1>

        <Form
          loginData={[
            { name: "Username", type: "text" },
            { name: "Email", type: "email" },
            { name: "Password", type: "password" },
          ]}
          buttonText="Signup"
          bgcolor="green"
          color="white"
        />
      </div>
    </div>
  );
};

export default Signup;