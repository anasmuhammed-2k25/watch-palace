import Nav from "../../components/nav/nav";
import "./homePage.css";

const Home = () => {
  console.log('hellooo')
  return (
    <div className="home-page">
      <Nav/>
      <section className="hero-section">
        <div className="hero-content">
          <h1>Welcome to MyApp </h1>
        </div>
      </section>
    </div>
  );
};

export default Home;