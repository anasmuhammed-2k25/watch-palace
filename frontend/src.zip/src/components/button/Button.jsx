import "./button.css";

const Button = ({ text, onclick,color,bgcolor }) => {
  return (
    <button    style={{ backgroundColor: bgcolor, color:color }} className="button" type="button" onClick={onclick}>
      {text}
    </button>
  );
};

export default Button;