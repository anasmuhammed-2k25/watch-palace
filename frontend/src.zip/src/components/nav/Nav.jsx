import Button from "../button/Button.jsx";
import "./nav.css";

const Nav = () => {
  return (
    <nav className="navbar">
      <div className="logo">MyApp</div>

      <ul className="nav-links">
        <li>Home</li>
        <li>About</li>
        <li>Services</li>
        <li>Contact</li>
      </ul>

      <div className="nav-actions">
        <Button
          text="Login"
          onclick={() => window.location = "/login"}
          bgcolor={'blue'}
          color={'white'}
        />
        <Button
          text="Signup"
          onclick={() => window.location = "/signup"}
          bgcolor={'green'}
          color={'white'}
        />
      </div>
    </nav>
  );
};

export default Nav;