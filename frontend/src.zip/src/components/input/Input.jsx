import "./input.css";

const Input = ({ name, type }) => {
  return (
    <div className="inputBox">
      <label htmlFor={name}>{name}</label>
      <input
        id={name}
        type={type}
        placeholder={`Enter your ${name}`}
      />
    </div>
  );
};

export default Input;