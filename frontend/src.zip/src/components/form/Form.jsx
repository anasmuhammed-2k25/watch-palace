import Button from "../button/Button";
import Input from "../input/Input";
import "./form.css";

const Form = ({
  loginData,
  buttonText,
  onSubmit,
  color,
  bgcolor,
}) => {
  return (
    <div className="form-container">
      <form className="form-box">
        {loginData.map((item, index) => (
          <Input key={index} name={item.name} type={item.type} />
        ))}

        <Button
          text={buttonText}
          onclick={onSubmit}
          bgcolor={bgcolor}
          color={color}
        />

    
        <a
          className="switch-link"
          href={buttonText === "Login" ? "/signup" : "/login"}
        >
          {buttonText === "Login" ? "Dont have an account" : "Alredy have an account"}
        </a>
      </form>
    </div>
  );
};

export default Form;